
#include <thread_safe_signals/shared_connection_block.hpp>

