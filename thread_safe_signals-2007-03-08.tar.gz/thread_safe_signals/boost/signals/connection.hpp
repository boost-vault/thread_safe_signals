
#include <thread_safe_signals/connection.hpp>

