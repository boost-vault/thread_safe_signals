
#include <boost/thread_safe_signals/signal_base.hpp>

