
#include <boost/thread_safe_signals/slot.hpp>

