
#include <boost/thread_safe_signals/single_threaded.hpp>

