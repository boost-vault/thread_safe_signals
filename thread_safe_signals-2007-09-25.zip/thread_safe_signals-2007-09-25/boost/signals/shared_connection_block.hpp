
#include <boost/thread_safe_signals/shared_connection_block.hpp>

