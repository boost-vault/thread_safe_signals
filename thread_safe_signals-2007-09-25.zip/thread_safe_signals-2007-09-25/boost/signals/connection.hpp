
#include <boost/thread_safe_signals/connection.hpp>

