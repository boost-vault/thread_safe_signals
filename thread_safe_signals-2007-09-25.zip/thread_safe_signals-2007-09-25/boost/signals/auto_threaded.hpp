
#include <boost/thread_safe_signals/auto_threaded.hpp>

